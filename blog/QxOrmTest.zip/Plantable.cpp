
#include "Plantable.h"
#include <QxOrm_Impl.h>
// 注册Plantable类的字段
QX_REGISTER_CPP_EXPORT_DLL(Plantable)
namespace qx
{
template <>
void register_class(QxClass<Plantable>& t)
{
    t.setName("plantable");
    t.id(&Plantable::planId, "planId");
    t.data(&Plantable::name, "name");
}

}  // namespace qx
