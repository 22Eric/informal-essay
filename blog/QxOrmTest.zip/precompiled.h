#ifndef PRECOMPILED_H
#define PRECOMPILED_H

// 这个宏控制 QxOrm 模板实现只在一个地方包含
#define QXORM_EXPORT_DLL

// 包含 QxOrm 库
#include <QxOrm.h>
#include "export.h"

#endif  // PRECOMPILED_H
