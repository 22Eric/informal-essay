#ifndef PLANTABLE_H
#define PLANTABLE_H

#include "precompiled.h"

class Plantable
{
public:
    QString planId;
    QString name;
};

QX_REGISTER_PRIMARY_KEY(Plantable, QString)
QX_REGISTER_HPP_EXPORT_DLL(Plantable, qx::trait::no_base_class_defined, 0)

#endif  // PLANTABLE_H
