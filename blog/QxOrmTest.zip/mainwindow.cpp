#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QSqlDatabase>
#include <QSqlError>
#include "Plantable.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    qx::QxSqlDatabase::getSingleton()->setDriverName("QMYSQL");
    qx::QxSqlDatabase::getSingleton()->setDatabaseName("test");
    qx::QxSqlDatabase::getSingleton()->setHostName("localhost");
    qx::QxSqlDatabase::getSingleton()->setUserName("root");
    qx::QxSqlDatabase::getSingleton()->setPassword("xingbg");
    qx::QxSqlDatabase::getSingleton()->setPort(3306);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    Plantable plant;
    plant.planId = "1";
    plant.name = "test";
    // // 插入记录
    qx::dao::insert(plant);
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->plainTextEdit->clear();
    // 查询全部记录
    // QList<Plantable> list;
    // qx::QxSqlDatabase::getSingleton()->setDatabaseName("test");
    // qx::dao::fetch_all(list);
    // for(int i = 0; i < list.size(); ++i)
    // {
    //     ui->plainTextEdit->appendPlainText(list[i].planId + " " + list[i].name);
    // }

    // 查询特定记录
    //  Plantable plant;
    //  plant.planId = "1";
    //  qx::dao::fetch_by_id(plant);
    //  ui->plainTextEdit->appendPlainText(plant.planId + " " + plant.name);

    // 查询符合条件的记录
    QList<Plantable> list;
    qx_query query;
    query.where("name").isEqualTo("test3");

    // 一些其他的查询条件
    // query.where("sex").isEqualTo(author::female)
    //     .and_("age").isGreaterThan(38)
    //     .or_("last_name").isNotEqualTo("Dupont")
    //     .or_("first_name").like("Alfred")
    //     .and_OpenParenthesis("id").isLessThanOrEqualTo(999)
    //     .and_("birth_date").isBetween(date1, date2)
    //     .closeParenthesis()
    //     .or_("id").in(50, 999, 11, 23, 78945)
    //     .and_("is_deleted").isNotNull()
    //     .orderAsc("last_name", "first_name", "sex")
    //     .limit(50, 150);

    qx::dao::fetch_by_query(query, list);
    for(int i = 0; i < list.size(); ++i)
    {
        ui->plainTextEdit->appendPlainText(list[i].planId + " " + list[i].name);
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    // 删除特定记录
    Plantable plant;
    plant.planId = "1";
    qx::dao::delete_by_id(plant);
}

void MainWindow::on_pushButton_4_clicked()
{
    // 更新记录
    Plantable plant;
    plant.planId = "1";
    plant.name = "test2";
    qx::dao::update(plant);
}

void MainWindow::on_pushButton_5_clicked()
{
    //  推荐使用保存。当记录不存在：insert，记录存在：update
    //  保存特定记录
    Plantable plant;
    plant.planId = "2";
    plant.name = "test3";
    qx::dao::save(plant);
}
